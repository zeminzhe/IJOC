Table2.R: to get Table 2 in the paper
RS2.R: needed to be sourced for Table2.R
Figure6.R: to get Figure 6 in the paper
Results-Sim23_7_5_Arabidopsis: the results have been stored in this file