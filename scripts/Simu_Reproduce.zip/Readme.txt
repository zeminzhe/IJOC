To reproduce the results in Results-Sim22_5_1_context
Run simu.R (Table 1), simu_p (Figure 1), simu_nout (Figure 2), simu_alpha (Figure 3), simu_spa (Figure 4), simu_snr (Figure 5)

Other files:
Function RS1.R for the proposed method
Function r4.1.R for R^4 method from She and Chen (2017): we slightly modify it to fix the maximum rank of this method for fair comparsion with competing methods
Function secure.R for sequential cosparse factor regression proposed by Mishra et al. (2017)
Function RCGL.R for rank constrained group Lasss proposed by Bunea et al. (2012)
Function RRR.R for reduced rank regression (RRR) for low-rank estimates