Just run Table4.R to get the results
To reproduce the results stored in Results-Sim22_12_15_rollingwindow and Results-Sim23_7_5_rollingwindow, please see the file named reproduce