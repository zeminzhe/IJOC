The results are already stored in Results-sim22_5_1_context

Function Table1.R to get the Table 1 in the paper
Function Figure.1.R to get the Figure 1 in the paper
Function Figure.2.R to get the Figure 2 in the paper
Function Figure.3.R to get the Figure 3 in the paper
Function Figure.4.R to get the Figure 4 in the paper
Function Figure.5.R to get the Figure 5 in the paper